package com.ikker.obdpicasso

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.hardware.usb.UsbDeviceConnection
import com.hoho.android.usbserial.driver.UsbSerialPort
import java.io.IOException
import java.util.UUID

/**
 * Canal hacia el adaptador ELM327. Puede ser Bluetooth (el adaptador "OBD Advanced" del C4 Picasso,
 * Bluetooth clásico con perfil serie) o un cable USB, por si la pantalla del coche no tiene Bluetooth.
 */
interface ObdLink {
    val bluetooth: Boolean
    /** Nombre para el registro y la pantalla de Ajustes. */
    val name: String
    /** Lectura bloqueante: devuelve los bytes leídos (0 si no llegó nada) o lanza IOException si se cortó. */
    @Throws(IOException::class) fun read(buf: ByteArray): Int
    @Throws(IOException::class) fun write(data: ByteArray)
    /** Solo USB: velocidad del puerto serie. En Bluetooth no existe. */
    fun setBaud(baud: Int) {}
    fun purge() {}
    fun close()
}

/** Cable OBD USB (como en la app del Ibiza). */
class UsbLink(private val port: UsbSerialPort, private val connection: UsbDeviceConnection, override val name: String) : ObdLink {
    override val bluetooth = false
    override fun read(buf: ByteArray): Int = port.read(buf, 0)
    override fun write(data: ByteArray) = port.write(data, 1000)
    override fun setBaud(baud: Int) = port.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
    override fun purge() { try { port.purgeHwBuffers(true, true) } catch (_: Exception) { } }
    override fun close() {
        try { port.close() } catch (_: Exception) { }
        try { connection.close() } catch (_: Exception) { }
    }
}

/** Adaptador ELM327 Bluetooth clásico (perfil serie SPP). */
class BtLink(private val socket: BluetoothSocket, override val name: String) : ObdLink {
    override val bluetooth = true
    private val input = socket.inputStream
    private val output = socket.outputStream
    override fun read(buf: ByteArray): Int {
        val n = input.read(buf)
        if (n < 0) throw IOException("El adaptador Bluetooth ha cerrado la conexión")
        return n
    }
    override fun write(data: ByteArray) { output.write(data); output.flush() }
    override fun purge() {
        try { while (input.available() > 0) input.skip(input.available().toLong()) } catch (_: Exception) { }
    }
    override fun close() { try { socket.close() } catch (_: Exception) { } }
}

/** Un adaptador Bluetooth emparejado en Android. */
data class BtDevice(val name: String, val address: String, val looksObd: Boolean)

@SuppressLint("MissingPermission")
object Bt {
    /** Identificador estándar del perfil serie (SPP), el que usan todos los ELM327 Bluetooth. */
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun adapter(ctx: Context): BluetoothAdapter? =
        try { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter } catch (_: Exception) { null }

    /** La tablet tiene Bluetooth. */
    fun available(ctx: Context) = adapter(ctx) != null
    fun enabled(ctx: Context) = try { adapter(ctx)?.isEnabled == true } catch (_: Exception) { false }

    /** Nombres típicos de los adaptadores ELM327 Bluetooth. */
    fun looksObd(name: String): Boolean {
        val n = name.uppercase()
        return listOf("OBD", "ELM", "V-LINK", "VLINK", "VGATE", "ICAR", "KONNWEI", "SCAN", "CAR", "OBDII", "OBD2").any { it in n }
    }

    /** Dispositivos emparejados, con los que parecen OBD primero. */
    fun paired(ctx: Context): List<BtDevice> = try {
        (adapter(ctx)?.bondedDevices ?: emptySet<BluetoothDevice>())
            .map { BtDevice(it.name ?: it.address, it.address, looksObd(it.name ?: "")) }
            .sortedWith(compareByDescending<BtDevice> { it.looksObd }.thenBy { it.name })
    } catch (_: Exception) { emptyList() }

    /**
     * Abre el canal serie con el adaptador. Primero la forma normal (segura); si el clon chino no la
     * acepta, la insegura; y si tampoco, por el canal 1 directamente (truco clásico para estos clones).
     */
    @Throws(IOException::class)
    fun open(ctx: Context, address: String, log: (String) -> Unit): BtLink {
        val ad = adapter(ctx) ?: throw IOException("Esta tablet no tiene Bluetooth")
        val dev = ad.getRemoteDevice(address)
        try { ad.cancelDiscovery() } catch (_: Exception) { }
        val name = dev.name ?: address
        var last: Exception? = null
        val ways: List<Pair<String, () -> BluetoothSocket>> = listOf(
            "segura" to { dev.createRfcommSocketToServiceRecord(SPP) },
            "insegura" to { dev.createInsecureRfcommSocketToServiceRecord(SPP) },
            "canal 1" to {
                dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(dev, 1) as BluetoothSocket
            },
        )
        for ((label, make) in ways) {
            var s: BluetoothSocket? = null
            try {
                s = make()
                s.connect()
                log("Bluetooth conectado a $name (conexión $label)")
                return BtLink(s, name)
            } catch (ex: Exception) {
                last = ex
                try { s?.close() } catch (_: Exception) { }
                log("Bluetooth $label: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
        throw IOException("No se pudo abrir el Bluetooth con $name: ${last?.message ?: "sin respuesta"}")
    }
}
