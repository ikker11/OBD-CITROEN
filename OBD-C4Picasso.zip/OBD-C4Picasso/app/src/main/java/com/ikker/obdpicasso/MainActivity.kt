package com.ikker.obdpicasso

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.NotificationCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * La conexión con el coche vive aquí, en la aplicación, y no en la pantalla. Así no se pierde al
 * salir a la radio, YouTube o el GPS, ni cuando Android cierra y vuelve a abrir la pantalla de la app.
 */
class ObdApplication : Application() {
    val vm: ObdViewModel by lazy { ObdViewModel(this).also { it.startSupervisor() } }
}

class MainActivity : ComponentActivity() {

    private val vm: ObdViewModel get() = (application as ObdApplication).vm

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Pantalla siempre encendida mientras la app está delante
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()
        setContent { ObdApp(vm) }
        // Conexión automática al abrir (adaptador Bluetooth o cable USB)
        vm.connect()
        askBackgroundPermissions()
    }

    /**
     * Pide, una sola vez, los permisos que evitan que Android corte la app en segundo plano:
     * mostrar la notificación del servicio y no ser "optimizada" por el ahorro de batería.
     */
    private fun askBackgroundPermissions() {
        val prefs = getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        try {
            // Bluetooth (adaptador OBD), notificación del servicio y ubicación (límite de velocidad), en una sola petición
            val ask = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
                !prefs.getBoolean("askedBt", false)
            ) {
                prefs.edit().putBoolean("askedBt", true).apply()
                ask += Manifest.permission.BLUETOOTH_CONNECT
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                !prefs.getBoolean("askedNotif", false)
            ) {
                prefs.edit().putBoolean("askedNotif", true).apply()
                ask += Manifest.permission.POST_NOTIFICATIONS
            }
            if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                !prefs.getBoolean("askedLocation", false)
            ) {
                prefs.edit().putBoolean("askedLocation", true).apply()
                ask += Manifest.permission.ACCESS_FINE_LOCATION
                ask += Manifest.permission.ACCESS_COARSE_LOCATION
            }
            if (ask.isNotEmpty() && Build.VERSION.SDK_INT >= 23) {
                requestPermissions(ask.toTypedArray(), 1)
                return
            }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(packageName) &&
                !prefs.getBoolean("askedBattery", false)
            ) {
                prefs.edit().putBoolean("askedBattery", true).apply()
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName")),
                )
            }
        } catch (_: Exception) { }
    }

    @Deprecated("Se sigue usando: es lo más sencillo para una sola petición")
    @Suppress("DEPRECATION")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        vm.refreshLocation()
        vm.refreshBt()
        vm.connect()                 // con el permiso de Bluetooth ya se puede conectar
        askBackgroundPermissions()   // sigue con la batería, si hace falta
    }

    override fun onResume() {
        super.onResume()
        vm.refreshLocation()   // por si se dio el permiso desde los ajustes de Android
        vm.refreshBt()         // por si se ha emparejado el adaptador mientras tanto
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    /** Oculta las barras de Android para aprovechar toda la pantalla del coche. */
    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) vm.connect()
    }
}

/**
 * Servicio en primer plano: mantiene viva la app (y con ella la conexión OBD) mientras estás en otras
 * aplicaciones. Solo muestra una notificación fija; la lectura la hace [ObdViewModel].
 */
class ObdService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "OBD C4 Picasso", NotificationManager.IMPORTANCE_LOW),
            )
        }
        goForeground("Leyendo el coche en segundo plano")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground("Leyendo el coche en segundo plano")
        if (watcher == null) {
            val vm = (application as ObdApplication).vm
            watcher = scope.launch {
                vm.state.map { it.conn to it.status }.distinctUntilChanged().collect { p ->
                    val text = when (p.first) {
                        Conn.CONECTADO -> "Conectado al coche"
                        Conn.CONECTANDO -> "Conectando con el coche…"
                        else -> p.second.take(80)
                    }
                    try {
                        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                        nm.notify(NOTIF_ID, notification(text))
                    } catch (_: Exception) { }
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun goForeground(text: String) {
        val n = notification(text)
        if (Build.VERSION.SDK_INT >= 29) {
            // Con permiso de ubicación, el servicio también mantiene vivo el GPS (límite de velocidad)
            val loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (loc) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            try {
                startForeground(NOTIF_ID, n, type)
            } catch (_: Exception) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            }
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("OBD C4 Picasso")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    companion object {
        private const val CHANNEL = "obd_picasso"
        private const val NOTIF_ID = 1
    }
}
