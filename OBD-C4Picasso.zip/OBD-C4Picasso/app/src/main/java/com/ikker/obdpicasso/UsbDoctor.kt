package com.ikker.obdpicasso

import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Resultado de una orden del sistema. */
class ShellResult(val ok: Boolean, val out: String)

/** Órdenes del sistema (normales o con root). Siempre con tiempo límite para no colgar la app. */
object Shell {
    fun run(vararg cmd: String, timeoutMs: Long = 8000): ShellResult = try {
        val p = ProcessBuilder(*cmd).redirectErrorStream(true).start()
        val out = StringBuilder()
        val reader = Thread {
            try { p.inputStream.bufferedReader().forEachLine { line -> synchronized(out) { out.appendLine(line) } } } catch (_: Exception) { }
        }
        reader.start()
        val done = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        if (!done) p.destroy()
        reader.join(500)
        ShellResult(done && p.exitValue() == 0, synchronized(out) { out.toString().trim() })
    } catch (e: Exception) {
        ShellResult(false, e.message ?: e.javaClass.simpleName)
    }

    /** Ejecuta un guion de shell como superusuario. La primera vez el gestor de root pide permiso. */
    fun su(script: String, timeoutMs: Long = 20_000): ShellResult = run("su", "-c", script, timeoutMs = timeoutMs)

    fun prop(name: String): String = run("getprop", name, timeoutMs = 2000).out.lineSequence().firstOrNull()?.trim().orEmpty()
}

/**
 * Diagnóstico del USB de la pantalla: datos del aparato, root y reinicio del controlador USB.
 * Sin root Android no deja cortar ni reiniciar el USB; con root se "desconecta" el controlador USB de su
 * driver y se vuelve a conectar, que lo arranca desde cero como al encender la pantalla.
 */
object UsbDoctor {
    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sbin/su", "/vendor/bin/su",
        "/system/bin/.ext/su", "/data/adb/magisk", "/data/adb/ksu",
    )

    /** ¿Hay un programa de root instalado? (no pide permiso) */
    fun suInstalled(): Boolean = suPaths.any { File(it).exists() }

    /** Pide root de verdad (sale el aviso del gestor de root) y dice si lo ha dado. */
    fun rootGranted(): Boolean = Shell.su("id", timeoutMs = 15_000).let { it.ok && it.out.contains("uid=0") }

    /** Datos de la pantalla para saber qué chip lleva (y qué guía de root le sirve). */
    fun deviceInfo(): List<Pair<String, String>> {
        val chip = buildList {
            if (Build.VERSION.SDK_INT >= 31) {
                val soc = "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim()
                if (soc.isNotBlank() && !soc.contains("unknown", ignoreCase = true)) add(soc)
            }
            Shell.prop("ro.board.platform").takeIf { it.isNotBlank() }?.let { add(it) }
            Shell.prop("ro.hardware").takeIf { it.isNotBlank() }?.let { add(it) }
            if (Build.HARDWARE.isNotBlank()) add(Build.HARDWARE)
        }.distinctBy { it.lowercase() }
        return listOf(
            "Modelo" to "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Chip" to chip.joinToString(" · ").ifEmpty { "—" },
            "Placa" to Build.BOARD.ifBlank { "—" },
            "Núcleo (kernel)" to (System.getProperty("os.version") ?: "—"),
        )
    }

    /** Número de bus USB a partir del nombre del dispositivo ("/dev/bus/usb/001/003" → 1). */
    fun busOf(deviceName: String): Int? =
        deviceName.split('/').filter { it.isNotBlank() }.let { p -> p.getOrNull(p.size - 2)?.toIntOrNull() }

    private fun hubs(bus: Int?) = if (bus != null) "/sys/bus/usb/devices/usb$bus" else "/sys/bus/usb/devices/usb*"

    /** Con root: ruta del controlador USB de cada bus (se guarda mientras funciona, por si luego se cuelga). */
    fun controllers(bus: Int?): List<String> {
        val script = "for h in ${hubs(bus)}; do [ -e \"\$h\" ] && readlink -f \"\$h/..\"; done"
        return Shell.su(script, 10_000).out.lines().map { it.trim() }.filter { it.startsWith("/sys/") }.distinct()
    }

    /**
     * Con root: vuelve a arrancar un dispositivo del sistema desconectándolo de su driver y conectándolo otra vez.
     * Devuelve lo que ha pasado, en palabras.
     */
    fun rebind(path: String): String {
        val script = listOf(
            "c=\"$path\"",
            "[ -e \"\$c/driver\" ] || { echo \"sin driver: \$c\"; exit 2; }",
            "d=\$(readlink -f \"\$c/driver\"); n=\$(basename \"\$c\")",
            "echo \"\$n\" > \"\$d/unbind\" && sleep 1 && echo \"\$n\" > \"\$d/bind\" && echo \"reiniciado \$n (\$(basename \"\$d\"))\"",
        ).joinToString("\n")
        val r = Shell.su(script, 15_000)
        return r.out.ifBlank { if (r.ok) "hecho" else "sin respuesta" }
    }

    /** Con root: reinicia el bus USB entero (todo lo conectado a él se vuelve a detectar). */
    fun resetBus(bus: Int?): String {
        val script = "for h in ${hubs(bus)}; do [ -e \"\$h/authorized\" ] && echo 0 > \"\$h/authorized\" && sleep 1 && echo 1 > \"\$h/authorized\" && echo \"bus \$(basename \$h) reiniciado\"; done"
        return Shell.su(script, 15_000).out.ifBlank { "sin respuesta" }
    }

    /** Mensajes del sistema sobre el USB (los del núcleo necesitan root). Es lo que dice por qué se cayó. */
    fun kernelUsbLines(root: Boolean, max: Int = 30): List<String> {
        val filter = "grep -i -E 'usb|xhci|ehci|ohci|dwc|musb|hub|ftdi|over-current|enumerat' | tail -n $max"
        val r = if (root) Shell.su("dmesg | $filter", 10_000) else Shell.run("sh", "-c", "dmesg 2>/dev/null | $filter", timeoutMs = 5000)
        return r.out.lines().map { it.trim() }.filter { it.isNotBlank() && !it.contains("Permission denied", ignoreCase = true) }
    }
}

/** Registro de desconexiones: se guarda en la pantalla y sobrevive a reinicios. */
class EventLog(private val file: File) {
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale("es", "ES"))
    private val maxLines = 500

    @Synchronized
    fun add(line: String, extra: List<String> = emptyList()) {
        try {
            val lines = (if (file.exists()) file.readLines() else emptyList()).toMutableList()
            lines += "${fmt.format(Date())} · $line"
            extra.forEach { lines += "      $it" }
            file.writeText(lines.takeLast(maxLines).joinToString("\n") + "\n")
        } catch (_: Exception) { }
    }

    /** Las últimas [n] líneas, en orden de hora (la más nueva al final). */
    @Synchronized
    fun last(n: Int): List<String> = try {
        if (file.exists()) file.readLines().takeLast(n) else emptyList()
    } catch (_: Exception) { emptyList() }

    @Synchronized
    fun all(): String = try { if (file.exists()) file.readText() else "" } catch (_: Exception) { "" }

    @Synchronized
    fun clear() { try { file.delete() } catch (_: Exception) { } }
}
