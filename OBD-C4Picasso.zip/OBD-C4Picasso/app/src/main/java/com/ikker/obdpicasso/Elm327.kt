package com.ikker.obdpicasso

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Comunicación con un adaptador ELM327 (u OBDLink/STN compatible) por Bluetooth o por USB-serie.
 * Todas las órdenes pasan por un Mutex, así el sondeo en tiempo real y las órdenes
 * manuales (leer averías, consola…) nunca se pisan.
 */
class Elm327(
    val link: ObdLink,
    private val onLog: (String) -> Unit,
) {
    private val lock = Mutex()
    var logTraffic = false
    /** Últimos bytes recibidos tal cual (para diagnosticar). */
    @Volatile private var lastRx = ""

    // ── Lectura continua ─────────────────────────────────────────────────────────────
    // Antes cada orden hacía lecturas USB con tiempo límite que, si no llegaba nada, se cancelaban.
    // Algunas pantallas chinas llevan controladores USB que se cuelgan con muchas cancelaciones, y
    // entonces solo vuelven reiniciando la pantalla. Ahora un único hilo lee sin parar (sin tiempo
    // límite, nunca se cancela nada) y deja lo que llega en un búfer; cada orden solo espera ahí.
    private val rx = StringBuilder()
    private val rxLock = Object()
    @Volatile private var running = true
    @Volatile private var readerError: IOException? = null
    private val reader = Thread({
        val b = ByteArray(4096)
        try {
            while (running) {
                val n = link.read(b)
                if (n > 0) synchronized(rxLock) { rx.append(String(b, 0, n, Charsets.ISO_8859_1)); rxLock.notifyAll() }
            }
        } catch (e: Exception) {
            if (running) {
                readerError = e as? IOException ?: IOException(e.message ?: e.javaClass.simpleName)
                synchronized(rxLock) { rxLock.notifyAll() }
            }
        }
    }, "obd-lectura").apply { isDaemon = true; start() }

    suspend fun send(cmd: String, timeoutMs: Long = 2500): String = lock.withLock {
        withContext(Dispatchers.IO) { raw(cmd, timeoutMs) }
    }

    @Throws(IOException::class)
    private fun raw(cmd: String, timeoutMs: Long): String {
        readerError?.let { throw it }
        // Vaciar restos de respuestas anteriores
        synchronized(rxLock) { rx.setLength(0) }
        link.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
        val end = System.currentTimeMillis() + timeoutMs
        val got: String
        synchronized(rxLock) {
            while (rx.indexOf(">") < 0) {
                readerError?.let { throw it }
                val left = end - System.currentTimeMillis()
                if (left <= 0) break
                rxLock.wait(left)
            }
            got = rx.toString()
            rx.setLength(0)
        }
        lastRx = got
        val cleaned = got
            .replace(">", "")
            .replace("\u0000", "")
            .split('\r', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(cmd, ignoreCase = true) }
            .filterNot { it.startsWith("SEARCHING", true) || it.startsWith("BUS INIT", true) }
            .joinToString("\n")
        if (logTraffic) onLog("> $cmd\n${cleaned.ifEmpty { "(sin respuesta)" }}")
        return cleaned
    }

    /**
     * Saludo al adaptador. El OBDLink EX trabaja siempre a 115200 baudios, así que no se prueba
     * ninguna otra velocidad: se fija esa, se vacían los buffers y se reinicia con ATZ.
     * Si no contesta, un segundo intento por la misma velocidad (por si seguía ocupado con algo
     * anterior). Devuelve la versión o null.
     */
    suspend fun handshake(): String? {
        if (link.bluetooth) return handshakeBt()
        try {
            link.setBaud(BAUD)
        } catch (ex: Exception) {
            onLog("No se pudo fijar $BAUD baudios: ${ex.message}")
            return null
        }
        link.purge()
        delay(300)   // deja que el chip USB termine de arrancar tras abrir el puerto
        onLog("Conectando a $BAUD baudios…")
        for (attempt in 1..2) {
            send("", 300)   // corta lo que hubiera a medias
            val r = send("ATZ", 3500)
            if (isAdapter(r)) {
                onLog("Adaptador encontrado: " + (r.lines().lastOrNull { isAdapter(it) } ?: r))
                return r.lines().lastOrNull { isAdapter(it) } ?: r
            }
            val hex = lastRx.toByteArray(Charsets.ISO_8859_1).joinToString(" ") { "%02X".format(it) }
            onLog("ATZ ($attempt) → " + hex.take(90).ifEmpty { "(silencio, 0 bytes)" })
        }
        return rescueBaud()
    }

    /**
     * Saludo por Bluetooth. Aquí no hay velocidad que elegir. Los clones baratos (como el "OBD Advanced")
     * tardan en reiniciarse con ATZ y a veces devuelven basura la primera vez, así que se insiste un poco;
     * si ATZ no contesta se prueba ATI, que no reinicia.
     */
    private suspend fun handshakeBt(): String? {
        link.purge()
        delay(500)
        onLog("Hablando con el adaptador por Bluetooth…")
        for (attempt in 1..3) {
            send("", 400)
            val r = send(if (attempt < 3) "ATZ" else "ATI", 4000)
            if (isAdapter(r)) {
                val v = r.lines().lastOrNull { isAdapter(it) } ?: r
                onLog("Adaptador encontrado: $v")
                if (v.contains("2.1")) onLog("Aviso: los clones que dicen ser v2.1 suelen ser los peores; si algo no lee, es por el adaptador")
                return v
            }
            val hex = lastRx.toByteArray(Charsets.ISO_8859_1).joinToString(" ") { "%02X".format(it) }
            onLog("Saludo ($attempt) → " + hex.take(90).ifEmpty { "(silencio, 0 bytes)" })
            delay(700)
        }
        return null
    }

    /**
     * Último recurso (solo USB), una vez por sesión: si no contesta a 115200 puede que tenga otra velocidad
     * guardada. Se prueban las demás y, si contesta, se le borran los ajustes para que vuelva a 115200.
     */
    private suspend fun rescueBaud(): String? {
        if (rescueDone) return null
        rescueDone = true
        onLog("Sin respuesta a $BAUD · probando otras velocidades (solo esta vez)")
        for (b in listOf(38400, 9600, 230400, 57600, 460800, 500000, 1000000, 2000000)) {
            try { link.setBaud(b) } catch (_: Exception) { continue }
            link.purge()
            send("", 200)
            val r = send("ATZ", 2000)
            if (!isAdapter(r)) continue
            onLog("El adaptador contesta a $b baudios · lo devuelvo a $BAUD de fábrica")
            send("STRSTNVM", 3000)
            send("STFAC", 3000)
            send("ATZ", 800)
            try { link.setBaud(BAUD) } catch (_: Exception) { }
            link.purge()
            delay(1000)
            send("", 300)
            val r2 = send("ATZ", 3500)
            if (isAdapter(r2)) {
                onLog("Adaptador recuperado a $BAUD baudios")
                return r2.lines().lastOrNull { isAdapter(it) } ?: r2
            }
            onLog("No se recuperó tras el reinicio")
            return null
        }
        try { link.setBaud(BAUD) } catch (_: Exception) { }
        onLog("No contesta a ninguna velocidad")
        return null
    }

    private fun isAdapter(r: String) = r.contains("ELM", true) || r.contains("STN", true) || r.contains("OBDLINK", true)

    fun close() {
        running = false
        link.close()   // desbloquea el hilo de lectura
    }

    companion object {
        /** Única velocidad usada con el adaptador. */
        const val BAUD = 115200

        /** Si ya se ha hecho el barrido de rescate en esta sesión de la app (para no repetirlo en cada reintento). */
        @Volatile private var rescueDone = false

        private val ERRORS = listOf("NO DATA", "UNABLE TO CONNECT", "CAN ERROR", "BUS ERROR", "STOPPED", "ERROR", "?")

        fun isError(r: String) = r.isBlank() || ERRORS.any { r.trim().uppercase().startsWith(it) }

        private val frameIndex = Regex("^[0-9A-F]:")
        private val byteCount = Regex("^[0-9A-F]{3}$")

        /** Convierte la respuesta en mensajes (lista de bytes). Junta tramas CAN multi-frame. */
        fun messages(resp: String): List<IntArray> {
            val lines = resp.uppercase().lines().map { it.replace(" ", "") }.filter { it.isNotEmpty() }
            val multi = lines.any { frameIndex.containsMatchIn(it) }
            val hexLines = if (multi) {
                var joined = lines.filter { frameIndex.containsMatchIn(it) }.joinToString("") { it.substring(2) }
                // La primera línea ("00F") dice cuántos bytes trae el mensaje: lo demás es relleno de la última trama
                val len = lines.firstOrNull { byteCount.matches(it) }?.toIntOrNull(16)
                if (len != null && len * 2 <= joined.length) joined = joined.substring(0, len * 2)
                listOf(joined)
            } else lines
            return hexLines.mapNotNull { l ->
                if (l.isEmpty() || l.length % 2 != 0 || !l.all { it in "0123456789ABCDEF" }) null
                else IntArray(l.length / 2) { i -> l.substring(i * 2, i * 2 + 2).toInt(16) }
            }
        }

        /** Datos de un PID del modo 01 ("41 PID A B …"). */
        fun mode01(resp: String, pid: Int): IntArray? {
            val need = Params.bytesFor(pid)
            for (m in messages(resp)) {
                if (m.size >= 2 + need && m[0] == 0x41 && m[1] == pid) return m.copyOfRange(2, 2 + need)
            }
            return null
        }

        /** Respuesta a una petición con varios PIDs ("01 0C 0D 05"): "41 0C xx xx 0D xx 05 xx" → mapa PID → datos. */
        fun mode01Multi(resp: String, wanted: List<Int>): Map<Int, IntArray> {
            val out = mutableMapOf<Int, IntArray>()
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x41) continue
                var i = 1
                while (i < m.size) {
                    val pid = m[i]
                    if (pid !in wanted) break
                    val n = Params.bytesFor(pid)
                    if (i + 1 + n > m.size) break
                    out[pid] = m.copyOfRange(i + 1, i + 1 + n)
                    i += 1 + n
                }
            }
            return out
        }

        /** Mapa de PIDs soportados (0100, 0120, …). */
        fun supported(resp: String, base: Int): Set<Int> {
            val out = mutableSetOf<Int>()
            for (m in messages(resp)) {
                if (m.size >= 6 && m[0] == 0x41 && m[1] == base) {
                    for (i in 0 until 32) {
                        val byte = m[2 + i / 8]
                        if (byte and (0x80 shr (i % 8)) != 0) out += base + i + 1
                    }
                }
            }
            return out
        }

        /**
         * Presión del colector de 2 bytes de los PID ampliados (en kPa absolutos, resolución 1/32):
         * 0187 = presión del colector · 0170 = control del turbo (se usa la presión real del sensor A).
         */
        fun extendedMap(resp: String, pid: Int): Double? {
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x41 || m[1] != pid) continue
                if (pid == 0x87 && m.size >= 5 && (m[2] and 0x01) != 0) return (m[3] * 256 + m[4]) / 32.0
                if (pid == 0x70 && m.size >= 7 && (m[2] and 0x02) != 0) return (m[5] * 256 + m[6]) / 32.0
            }
            return null
        }

        /** Datos de un ReadDataByIdentifier UDS ("62 DID_H DID_L A B …"). */
        fun mode22(resp: String, did: Int): IntArray? {
            for (m in messages(resp)) {
                if (m.size >= 4 && m[0] == 0x62 && m[1] == (did shr 8) && m[2] == (did and 0xFF)) return m.copyOfRange(3, m.size)
            }
            return null
        }

        /** Respuesta a "0100": PIDs 01-20 soportados, o null si el coche no ha contestado. */
        fun mode01Supported(resp: String): Set<Int>? =
            if (messages(resp).any { it.size >= 6 && it[0] == 0x41 && it[1] == 0x00 }) supported(resp, 0x00) else null

        /** Códigos de avería de los modos 03 (43), 07 (47) o 0A (4A). */
        fun dtcs(resp: String, header: Int): List<String> {
            val out = linkedSetOf<String>()
            for (m in messages(resp)) {
                if (m.isEmpty() || m[0] != header) continue
                var data = m.copyOfRange(1, m.size)
                // En CAN el primer byte es el número de códigos (quedaría impar)
                if (data.size % 2 == 1) data = data.copyOfRange(1, data.size)
                var i = 0
                while (i + 1 < data.size) {
                    val a = data[i]; val b = data[i + 1]
                    if (a != 0 || b != 0) out += decodeDtc(a, b)
                    i += 2
                }
            }
            return out.toList()
        }

        /**
         * Memoria de averías propia de la centralita (UDS, servicio 19 02): "59 02 máscara [H M L estado]…".
         * Es la que leen los equipos de taller. null si la centralita no contestó a la petición.
         */
        fun udsDtcs(resp: String): List<UdsDtc>? {
            var answered = false
            val out = linkedMapOf<String, Int>()
            val ftbs = mutableMapOf<String, Int>()
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x59 || m[1] != 0x02) continue
                answered = true
                var i = 3
                while (i + 3 < m.size) {
                    val h = m[i]; val mid = m[i + 1]; val ftb = m[i + 2]; val status = m[i + 3]
                    // Solo averías de verdad: fallando ahora (bit 0), pendiente (bit 2) o confirmada (bit 3).
                    // Las que solo tienen "prueba no completada" (bits 4 y 6), que salen todas tras un borrado, no lo son.
                    if ((h != 0 || mid != 0) && (status and 0x0D) != 0) {
                        val code = decodeDtc(h, mid)
                        out[code] = (out[code] ?: 0) or status
                        if (code !in ftbs || (status and 0x01) != 0) ftbs[code] = ftb
                    }
                    i += 4
                }
            }
            return if (answered) out.map { UdsDtc(it.key, it.value, ftbs[it.key] ?: 0) } else null
        }

        /** ¿Hay respuesta positiva al servicio [sid]? (la positiva es sid + 0x40). */
        fun positive(resp: String, sid: Int): Boolean = messages(resp).any { it.isNotEmpty() && it[0] == sid + 0x40 }

        /** Código de rechazo ("7F sid código") del servicio [sid], sin contar el "espera" (78). */
        fun nrc(resp: String, sid: Int): Int? =
            messages(resp).firstOrNull { it.size >= 3 && it[0] == 0x7F && it[1] == sid && it[2] != 0x78 }?.get(2)

        /** Motivo de rechazo en palabras. */
        fun nrcText(code: Int?): String = when (code) {
            null -> "sin respuesta"
            0x11, 0x12 -> "no admite esta orden"
            0x13 -> "orden mal formada"
            0x22 -> "condiciones no válidas: motor en marcha o algo en curso"
            0x31 -> "fuera de rango"
            0x33 -> "acceso protegido"
            0x7E, 0x7F -> "no se admite en esta sesión"
            else -> "rechazado (%02X)".format(code)
        }

        fun decodeDtc(a: Int, b: Int): String {
            val letter = "PCBU"[a shr 6]
            return "%c%d%X%02X".format(letter, (a shr 4) and 0x3, a and 0xF, b)
        }

        /** Número de bastidor (modo 09 PID 02). */
        fun vin(resp: String): String? {
            val bytes = messages(resp).flatMap { it.toList() }
            val idx = bytes.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == 0x02 }
            if (idx < 0) return null
            val chars = bytes.drop(idx + 2)
                .filter { it in 0x30..0x5A }
                .map { it.toChar() }
                .joinToString("")
            return if (chars.length >= 17) chars.takeLast(17) else chars.ifEmpty { null }
        }
    }
}

/**
 * Avería de la memoria propia de la centralita (UDS). [status] es el byte de estado ISO 14229 y [ftb]
 * el tipo de fallo SAE J2012 (circuito abierto, cortocircuito a masa…).
 */
data class UdsDtc(val code: String, val status: Int, val ftb: Int = 0) {
    /** El fallo está presente ahora mismo. */
    val active: Boolean get() = (status and 0x01) != 0
    val pending: Boolean get() = (status and 0x04) != 0
    val confirmed: Boolean get() = (status and 0x08) != 0
    /** La centralita pide encender el testigo de avería. */
    val mil: Boolean get() = (status and 0x80) != 0
    /** Ha fallado alguna vez desde el último borrado, pero ahora no. */
    val sporadic: Boolean get() = !active && (confirmed || (status and 0x20) != 0)
    val label: String get() = when {
        active -> "Activa ahora: el fallo sigue presente"
        confirmed -> "Guardada · ya no está activa"
        pending -> "Pendiente de confirmar"
        else -> "En el historial"
    }
}
