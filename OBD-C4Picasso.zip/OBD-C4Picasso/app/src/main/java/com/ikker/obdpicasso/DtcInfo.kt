package com.ikker.obdpicasso

/** Gravedad de una avería: cuánto afecta al coche y con qué urgencia hay que atenderla. */
enum class Severity(val label: String, val advice: String) {
    LEVE("Leve", "Se puede circular con normalidad. Revísalo en la próxima visita al taller."),
    MODERADA("Moderada", "Se puede circular, pero puede haber pérdida de potencia o más consumo. Revísalo pronto."),
    GRAVE("Grave", "Puede activar el modo de emergencia o dañar otros componentes. Revísalo cuanto antes y evita exigir al motor."),
    CRITICA("Crítica", "Riesgo de avería mayor o de que el motor se pare. Detén el coche en cuanto sea seguro y no sigas circulando."),
}

/**
 * Ficha técnica de una avería: título normalizado (SAE J2012), componente,
 * gravedad, efecto en el coche, causas ordenadas de más a menos probable y comprobaciones a seguir.
 */
class DtcDef(
    val title: String,
    val component: String,
    val severity: Severity,
    val effect: String,
    val causes: List<String>,
    val checks: List<String>,
    val note: String? = null,
)

/** Fichas de averías de un diésel common rail (las genéricas SAE valen para el 1.6 HDi del C4 Picasso). */
object DtcInfo {

    // ── Textos que se repiten en varias fichas
    private const val WIRING = "Cableado o conector dañado, suelto o con los terminales oxidados"
    private const val CHECK_CONNECTOR = "Desconecta la batería, revisa el conector del componente (terminales, enclavamiento, humedad) y el mazo hasta la centralita"
    private const val CHECK_LIVE = "Con el motor en marcha, comprueba el valor en Datos en vivo: debe ser estable y coherente con el resto de lecturas"
    private const val AFTER = "Tras reparar, borra las averías y conduce un ciclo completo para que la centralita lo vuelva a comprobar"

    private fun d(
        title: String, component: String, severity: Severity, effect: String,
        causes: List<String>, checks: List<String>, note: String? = null,
    ) = DtcDef(title, component, severity, effect, causes, checks + AFTER, note)

    /** Las cuatro averías típicas de un sensor: circuito, rango, señal baja y señal alta. */
    private fun sensor(
        base: Int, name: String, ref: String, severity: Severity, effect: String, live: String,
    ): List<Pair<String, DtcDef>> {
        val comp = name
        return listOf(
            "P%04X".format(base) to d(
                "$name: avería en el circuito", comp, severity, effect,
                listOf(WIRING, "Sensor averiado", "Fallo de alimentación o de masa del sensor"),
                listOf(CHECK_CONNECTOR, "Mide con el polímetro la alimentación y la masa en el conector con el contacto puesto", live),
            ),
            "P%04X".format(base + 1) to d(
                "$name: señal fuera de rango o funcionamiento incorrecto", comp, severity, effect,
                listOf("Sensor descalibrado o sucio", "Lectura no coherente con los demás sensores (fuga, obstrucción o fallo mecánico en el sistema)", WIRING),
                listOf(live, "Compara la lectura con la de otro sensor relacionado en las mismas condiciones", CHECK_CONNECTOR),
            ),
            "P%04X".format(base + 2) to d(
                "$name: señal baja", comp, severity, effect,
                listOf("Cortocircuito a masa o circuito abierto en el cable de señal", "Sensor averiado", "Conector desenchufado"),
                listOf("Comprueba que el conector del sensor está bien enchufado", CHECK_CONNECTOR, "Mide la continuidad del cable de señal y su aislamiento a masa"),
            ),
            "P%04X".format(base + 3) to d(
                "$name: señal alta", comp, severity, effect,
                listOf("Cortocircuito a positivo en el cable de señal", "Masa del sensor interrumpida", "Sensor averiado"),
                listOf(CHECK_CONNECTOR, "Mide la continuidad de la masa del sensor y que la señal no esté unida a positivo", live),
            ),
        )
    }

    private val defs: Map<String, DtcDef> by lazy {
        val m = mutableMapOf<String, DtcDef>()

        // ── Medición de aire
        m += sensor(
            0x100, "Medidor de masa de aire", "G70", Severity.MODERADA,
            "La centralita pasa a usar un valor de sustitución: menos potencia, posible humo negro al acelerar y testigo de avería.",
            "En Datos en vivo → Caudal de aire, el valor debe subir de forma progresiva con las revoluciones y volver al de ralentí al soltar",
        )
        m["P0101"] = d(
            "Medidor de masa de aire: señal fuera de rango o funcionamiento incorrecto", "Medidor de masa de aire", Severity.MODERADA,
            "Mezcla aire/combustible incorrecta: pérdida de potencia, humo negro y posible modo de emergencia.",
            listOf(
                "Toma de aire no medida entre el medidor de aire y el turbo (manguito suelto, abrazadera floja, admisión mal sellada)",
                "Medidor sucio o envejecido",
                "Filtro de aire obstruido o admisión de alto flujo que altera la lectura del sensor",
                "Fuga de presión de turbo o fallo de la EGR que descuadra el caudal esperado",
            ),
            listOf(
                "Revisa el filtro, la caja y todos los manguitos desde el medidor de aire hasta el turbo",
                "En Datos en vivo compara el caudal de aire con la carga y la presión de turbo al acelerar",
                "Comprueba que no hay fugas de presión en el intercooler y sus manguitos",
            ),
        )
        m += sensor(
            0x105, "Sensor de presión de sobrealimentación", "G31", Severity.MODERADA,
            "Regulación de turbo y de inyección con un valor de sustitución: pérdida de potencia.",
            "En Datos en vivo → Presión colector, con el contacto puesto y el motor parado debe marcar lo mismo que la presión atmosférica",
        )
        m += sensor(
            0x110, "Sensor de temperatura del aire de admisión", "G42", Severity.LEVE,
            "La centralita usa una temperatura de sustitución; efecto pequeño en el arranque en frío y la regulación del turbo.",
            "En Datos en vivo → Aire admisión, con el motor frío debe marcar casi la temperatura exterior",
        )
        m += sensor(
            0x115, "Sensor de temperatura del refrigerante", "G62", Severity.GRAVE,
            "El ventilador puede quedar funcionando siempre, el arranque en frío empeora y se pierde la vigilancia de sobrecalentamiento.",
            "En Datos en vivo → Refrigerante, con el motor frío debe marcar la temperatura ambiente y subir de forma continua al arrancar",
        )
        m["P0128"] = d(
            "Temperatura del refrigerante por debajo de la de regulación del termostato", "Termostato del circuito de refrigeración", Severity.LEVE,
            "El motor tarda mucho en calentarse: más consumo, calefacción floja y más hollín en el filtro de partículas.",
            listOf("Termostato atascado abierto", "Sensor de temperatura que lee de menos", "Ventilador del radiador funcionando sin motivo"),
            listOf(
                "En Datos en vivo → Refrigerante, tras 10–15 minutos de conducción debe llegar a unos 85–90 °C y mantenerse",
                "Comprueba que el manguito superior del radiador no se calienta hasta que el motor está caliente",
            ),
        )
        m += sensor(
            0x180, "Sensor de temperatura del combustible", "G81", Severity.LEVE,
            "La centralita corrige la inyección con un valor de sustitución; efecto pequeño.",
            "Con el motor frío la temperatura del combustible debe ser parecida a la exterior",
        )
        m += sensor(
            0x190, "Sensor de presión del combustible (rail)", "G247", Severity.GRAVE,
            "La presión de inyección se regula sin lectura real: potencia muy limitada, posible parada del motor o dificultad para arrancar.",
            "En Datos en vivo → Rail, al ralentí la presión debe ser estable y subir al acelerar",
        )

        // ── Presión de combustible
        m["P0087"] = d(
            "Presión del rail demasiado baja", "Sistema de alta presión de combustible", Severity.GRAVE,
            "Pérdida de potencia, tirones y posible parada del motor o no arranque.",
            listOf(
                "Filtro de combustible obstruido",
                "Aire en el circuito o fuga en el lado de baja presión",
                "Bomba de alta presión desgastada",
                "Válvula dosificadora o reguladora con fallo",
                "Retorno excesivo de algún inyector",
            ),
            listOf(
                "Sustituye el filtro de combustible si tiene muchos kilómetros",
                "En Datos en vivo → Rail, compara la presión real con la pedida al acelerar a fondo",
                "Haz una prueba de caudal de retorno de los inyectores",
            ),
        )
        m["P0088"] = d(
            "Presión del rail demasiado alta", "Sistema de alta presión de combustible", Severity.GRAVE,
            "La centralita limita la potencia para proteger los inyectores; puede llegar a parar el motor.",
            listOf("Válvula reguladora de presión atascada o con fallo", "Retorno de combustible obstruido", "Sensor que lee de más"),
            listOf(
                "Comprueba que el tubo de retorno al depósito no está pinzado ni obstruido",
                "Revisa la válvula y su conector",
                "En Datos en vivo → Rail, compara la presión real con la pedida",
            ),
        )
        m["P0089"] = d(
            "Regulador de presión de combustible: funcionamiento incorrecto", "Válvula reguladora de presión del combustible", Severity.GRAVE,
            "La presión del rail oscila: tirones, ralentí inestable y posible parada.",
            listOf("Válvula sucia o averiada", "Combustible contaminado", WIRING),
            listOf(CHECK_CONNECTOR, "Observa en Datos en vivo → Rail si la presión oscila al ralentí", "Comprueba el estado del combustible y del filtro"),
        )
        m["P0093"] = d(
            "Fuga de combustible detectada (fuga grande)", "Sistema de alta presión de combustible", Severity.CRITICA,
            "Riesgo de incendio y parada del motor. La centralita puede cortar la inyección.",
            listOf("Tubo de alta presión flojo o rajado", "Fuga en un inyector o en su asiento", "Fuga en la bomba de alta presión"),
            listOf("No arranques el motor si huele a gasóleo en el vano motor", "Revisa visualmente los tubos de alta presión, el rail y los inyectores"),
        )

        // ── Inyectores
        m["P0200"] = d(
            "Circuito de los inyectores: avería", "Inyectores y su etapa de mando en la centralita", Severity.GRAVE,
            "Funcionamiento irregular o parada del motor.",
            listOf(WIRING, "Inyector averiado", "Etapa de potencia de la centralita dañada"),
            listOf(CHECK_CONNECTOR, "Mide la resistencia de cada inyector y compárala entre ellos"),
        )
        for (cyl in 1..4) {
            val comp = "Inyector del cilindro $cyl"
            m["P020$cyl"] = d(
                "Inyector del cilindro $cyl: avería en el circuito", comp, Severity.GRAVE,
                "El cilindro $cyl deja de inyectar: el motor vibra, pierde potencia y puede echar humo.",
                listOf(WIRING, "Inyector averiado (bobina abierta o en cortocircuito)"),
                listOf("Revisa el conector del inyector", "Mide la resistencia del inyector y compárala con la de los demás", "Mide la continuidad de los dos cables hasta la centralita"),
            )
        }
        listOf(1 to 0x261, 2 to 0x264, 3 to 0x267, 4 to 0x270).forEach { (cyl, c) ->
            m["P%04X".format(c)] = d(
                "Inyector del cilindro $cyl: circuito con tensión baja", "Inyector del cilindro $cyl", Severity.GRAVE,
                "El cilindro $cyl inyecta mal o no inyecta: vibraciones y pérdida de potencia.",
                listOf("Cortocircuito a masa en el cableado del inyector", "Inyector averiado"),
                listOf("Revisa el conector y el mazo del inyector", "Mide el aislamiento a masa de los cables del inyector"),
            )
            m["P%04X".format(c + 1)] = d(
                "Inyector del cilindro $cyl: circuito con tensión alta", "Inyector del cilindro $cyl", Severity.GRAVE,
                "El cilindro $cyl inyecta mal o no inyecta: vibraciones y pérdida de potencia.",
                listOf("Circuito abierto o cortocircuito a positivo", "Inyector averiado"),
                listOf("Revisa el conector y el mazo del inyector", "Mide la continuidad de los cables hasta la centralita"),
            )
        }
        m["P0300"] = d(
            "Combustión irregular detectada en varios cilindros", "Combustión / inyección", Severity.GRAVE,
            "Vibraciones, tirones y pérdida de potencia.",
            listOf("Inyectores con caudal desigual", "Compresión baja en uno o varios cilindros", "Combustible de mala calidad o aire en el circuito"),
            listOf("Haz una prueba de caudal de retorno de los inyectores", "Mide la compresión de los cilindros"),
        )
        for (cyl in 1..4) m["P030$cyl"] = d(
            "Combustión irregular en el cilindro $cyl", "Cilindro $cyl: inyector y combustión", Severity.GRAVE,
            "Vibración y pérdida de potencia; si sigue, puede dañar el filtro de partículas.",
            listOf("Inyector con caudal incorrecto", "Compresión baja en el cilindro $cyl", "Bujía de incandescencia averiada (en frío)"),
            listOf("Haz una prueba de caudal de retorno del inyector", "Mide la compresión del cilindro $cyl"),
        )

        // ── Régimen y distribución
        m["P0016"] = d(
            "Correlación entre cigüeñal y árbol de levas", "Sensores / distribución", Severity.CRITICA,
            "La sincronización del motor no es correcta: dificultad para arrancar y riesgo de daño grave si la correa ha saltado.",
            listOf("Correa de distribución que ha saltado un diente o tensor defectuoso", "Rueda fónica dañada", "Sensor con fallo"),
            listOf("No fuerces el motor hasta comprobar la distribución", "Revisa el calado de la distribución con las herramientas de bloqueo", "Revisa los sensores y sus conectores"),
        )
        m["P0335"] = d(
            "Sensor de régimen del motor (cigüeñal): avería en el circuito", "Sensor de régimen del motor", Severity.CRITICA,
            "Sin esta señal el motor se para y no arranca.",
            listOf(WIRING, "Sensor averiado", "Rueda fónica dañada o sucia"),
            listOf(CHECK_CONNECTOR, "Revisa el sensor del cigüeñal y la separación con la rueda fónica"),
        )
        m["P0336"] = d(
            "Sensor de régimen del motor (cigüeñal): señal fuera de rango", "Sensor de régimen del motor", Severity.GRAVE,
            "Tirones, cortes o el motor se para.",
            listOf("Rueda fónica dañada o sucia", "Sensor con holgura o averiado", "Interferencias en el cableado"),
            listOf("Revisa el sensor del cigüeñal y su fijación", CHECK_CONNECTOR),
        )
        m["P0340"] = d(
            "Sensor del árbol de levas: avería en el circuito", "Sensor Hall del árbol de levas", Severity.GRAVE,
            "Arranque más largo; con el motor ya en marcha suele seguir funcionando.",
            listOf(WIRING, "Sensor averiado"),
            listOf(CHECK_CONNECTOR, "Mide la alimentación y la masa del sensor del árbol de levas con el contacto puesto"),
        )
        m["P0341"] = d(
            "Sensor del árbol de levas: señal fuera de rango", "Sensor Hall del árbol de levas", Severity.GRAVE,
            "Arranque más largo o irregular.",
            listOf("Rueda generatriz del árbol de levas dañada", "Distribución desfasada", "Sensor averiado"),
            listOf("Revisa el calado de la distribución", "Revisa el sensor del árbol de levas y su conector"),
        )

        // ── Precalentamiento
        m["P0380"] = d(
            "Precalentamiento: avería en el circuito", "Unidad de control de precalentamiento", Severity.MODERADA,
            "Arranque difícil en frío y humo blanco los primeros minutos.",
            listOf("Unidad averiada", "Bujías de incandescencia averiadas", WIRING),
            listOf("Comprueba cada bujía de incandescencia", "Revisa la alimentación y el mando de la unidad de precalentamiento"),
        )
        m["P0381"] = d(
            "Testigo de precalentamiento: avería en el circuito", "Testigo de precalentamiento", Severity.LEVE,
            "Solo afecta al aviso del cuadro.",
            listOf("Testigo del cuadro fundido", WIRING),
            listOf("Comprueba que el testigo se enciende al poner el contacto"),
        )
        m["P0670"] = d(
            "Módulo de precalentamiento: avería en el circuito", "Unidad de control de precalentamiento", Severity.MODERADA,
            "Arranque difícil en frío.",
            listOf("Unidad averiada", WIRING),
            listOf(CHECK_CONNECTOR, "Comprueba la alimentación de la unidad de precalentamiento y su fusible"),
        )
        for (cyl in 1..4) m["P067$cyl"] = d(
            "Bujía de incandescencia del cilindro $cyl: avería en el circuito", "Bujía de incandescencia del cilindro $cyl (Q${9 + cyl})", Severity.LEVE,
            "Arranque peor en frío y más humo al arrancar.",
            listOf("Bujía Q${9 + cyl} fundida", "Conector de la bujía suelto u oxidado"),
            listOf("Mide la resistencia de la bujía Q${9 + cyl} y compárala con la de las demás", "Revisa su conector"),
        )
        m["P0683"] = d(
            "Comunicación entre la centralita y el módulo de precalentamiento", "Unidad de control de precalentamiento", Severity.MODERADA,
            "El precalentamiento puede no funcionar: arranque difícil en frío.",
            listOf("Cable de comunicación con la unidad de precalentamiento dañado", "Unidad averiada"),
            listOf(CHECK_CONNECTOR),
        )

        // ── EGR
        val egrNote = "Si alguien ha anulado la EGR, el programa de la centralita tiene que tener desactivada esta vigilancia. Si aparece, la anulación no está bien hecha por software."
        m["P0400"] = d(
            "Recirculación de gases de escape (EGR): caudal incorrecto", "Sistema de recirculación de gases (EGR)", Severity.MODERADA,
            "Más emisiones y posible limitación de potencia.",
            listOf("Válvula EGR sucia o atascada", "Fuga en los conductos de la EGR", "Medidor de aire con lectura falsa"),
            listOf("Revisa la válvula EGR y sus conductos", "Comprueba en Datos en vivo → EGR que la válvula responde"),
            egrNote,
        )
        m["P0401"] = d(
            "Recirculación de gases de escape (EGR): caudal insuficiente", "Sistema de recirculación de gases (EGR)", Severity.MODERADA,
            "Más emisiones de NOx; normalmente sin efecto en la conducción.",
            listOf("Válvula EGR obstruida por carbonilla", "Válvula EGR anulada o tapada mecánicamente", "Radiador de la EGR obstruido", "Medidor de aire que lee de más"),
            listOf("Limpia o revisa la válvula EGR", "Comprueba en Datos en vivo que el caudal de aire baja cuando la EGR abre al ralentí"),
            egrNote,
        )
        m["P0402"] = d(
            "Recirculación de gases de escape (EGR): caudal excesivo", "Válvula EGR", Severity.MODERADA,
            "Humo negro, pérdida de potencia y posible modo de emergencia.",
            listOf("Válvula EGR atascada abierta", "Medidor de aire que lee de menos"),
            listOf("Comprueba que la válvula EGR cierra del todo", "Revisa el medidor de aire"),
            egrNote,
        )
        m["P0403"] = d(
            "Válvula EGR: avería en el circuito de mando", "Motor de la válvula EGR", Severity.MODERADA,
            "La EGR queda sin control; posible limitación de potencia.",
            listOf("Conector de la válvula EGR desenchufado", WIRING, "Motor de la válvula averiado"),
            listOf(CHECK_CONNECTOR, "Mide la resistencia del motor de la válvula"),
            egrNote,
        )
        m["P0404"] = d(
            "Válvula EGR: posición fuera de rango o funcionamiento incorrecto", "Válvula EGR y su sensor de posición", Severity.MODERADA,
            "La EGR no alcanza la posición pedida; posible limitación de potencia.",
            listOf("Válvula EGR sucia o agarrotada", "Sensor de posición de la EGR averiado"),
            listOf("Limpia la válvula EGR y comprueba que se mueve libre", "Revisa el sensor de posición y su conector"),
            egrNote,
        )
        m["P0405"] = d(
            "Sensor de posición de la EGR: señal baja", "Sensor de posición de la válvula EGR", Severity.MODERADA,
            "La EGR se regula sin lectura de posición.",
            listOf("Conector desenchufado", "Cortocircuito a masa en la señal", "Sensor averiado"),
            listOf(CHECK_CONNECTOR), egrNote,
        )
        m["P0406"] = d(
            "Sensor de posición de la EGR: señal alta", "Sensor de posición de la válvula EGR", Severity.MODERADA,
            "La EGR se regula sin lectura de posición.",
            listOf("Masa del sensor interrumpida", "Cortocircuito a positivo en la señal", "Sensor averiado"),
            listOf(CHECK_CONNECTOR), egrNote,
        )
        m["P0409"] = d(
            "Sensor de la EGR: avería en el circuito", "Sensor de posición de la válvula EGR", Severity.MODERADA,
            "La EGR se regula sin lectura de posición.",
            listOf(WIRING, "Sensor averiado"),
            listOf(CHECK_CONNECTOR), egrNote,
        )
        m["P2425"] = d(
            "Válvula de conmutación del radiador de la EGR: avería en el circuito", "Válvula de conmutación del radiador EGR", Severity.LEVE,
            "El radiador de la EGR no conmuta; más emisiones en frío.",
            listOf(WIRING, "Válvula averiada", "Tubo de vacío suelto o roto"),
            listOf(CHECK_CONNECTOR, "Revisa los tubos de vacío de la válvula"),
            egrNote,
        )

        // ── Turbo
        m["P0045"] = d(
            "Regulación de la presión de sobrealimentación: avería en el circuito", "Electroválvula de limitación de la presión de sobrealimentación", Severity.GRAVE,
            "El turbo queda sin control: modo de emergencia con poca potencia.",
            listOf("Conector de la electroválvula del turbo desenchufado", WIRING, "Electroválvula averiada"),
            listOf(CHECK_CONNECTOR, "Mide la resistencia de la electroválvula del turbo", "Revisa los tubos de vacío de la electroválvula del turbo al turbo"),
        )
        m["P0234"] = d(
            "Sobrepresión del turbo", "Regulación de la presión de sobrealimentación", Severity.GRAVE,
            "La centralita corta la potencia (modo de emergencia) hasta apagar y volver a arrancar el motor.",
            listOf(
                "Presión pedida por encima del límite de sobrepresión del programa (frecuente en motores reprogramados)",
                "Geometría variable del turbo agarrotada en posición cerrada",
                "Electroválvula o tubos de vacío con fallo",
            ),
            listOf(
                "En Datos en vivo → Turbo, compara la presión máxima con la que admite el programa",
                "Comprueba que la varilla de la geometría variable se mueve libre en todo su recorrido",
                "Revisa la electroválvula del turbo y sus tubos de vacío",
            ),
        )
        m["P0299"] = d(
            "Presión del turbo insuficiente", "Sistema de sobrealimentación", Severity.GRAVE,
            "Pérdida de potencia clara y posible modo de emergencia.",
            listOf(
                "Fuga de presión: manguito del intercooler suelto o rajado",
                "Geometría variable del turbo agarrotada (carbonilla)",
                "Electroválvula o tubos de vacío con fallo",
                "Turbo desgastado",
            ),
            listOf(
                "Revisa todos los manguitos y abrazaderas del turbo al colector, y el intercooler",
                "En Datos en vivo → Turbo, compara la presión real con la pedida al acelerar a fondo en 3.ª",
                "Comprueba que la geometría variable se mueve libre",
            ),
        )
        m["P2562"] = d(
            "Sensor de posición de la geometría variable del turbo: avería en el circuito", "Sensor de posición del turbo", Severity.GRAVE,
            "El turbo se regula sin lectura de posición: modo de emergencia.",
            listOf(WIRING, "Sensor de posición averiado"),
            listOf(CHECK_CONNECTOR),
        )
        m["P2563"] = d(
            "Sensor de posición de la geometría variable del turbo: señal fuera de rango", "Sensor de posición del turbo", Severity.GRAVE,
            "Regulación del turbo incorrecta: pérdida de potencia o sobrepresión.",
            listOf("Geometría variable agarrotada", "Sensor de posición desajustado o averiado"),
            listOf("Comprueba que la varilla de la geometría variable se mueve libre", CHECK_CONNECTOR),
        )
        m["P2263"] = d(
            "Sistema de sobrealimentación: funcionamiento incorrecto", "Sistema de sobrealimentación", Severity.GRAVE,
            "La presión no sigue a la pedida: pérdida de potencia o tirones.",
            listOf("Fuga de presión en manguitos o intercooler", "Geometría variable agarrotada", "Electroválvula del turbo o tubos de vacío con fallo"),
            listOf("Revisa manguitos, abrazaderas e intercooler", "En Datos en vivo → Turbo, compara la presión real con la pedida"),
        )

        // ── Escape y filtro de partículas
        m["P0420"] = d(
            "Eficiencia del catalizador por debajo del umbral", "Catalizador de oxidación", Severity.LEVE,
            "Más emisiones; sin efecto en la conducción.",
            listOf("Catalizador envejecido o dañado", "Escape modificado o sin catalizador", "Fuga en el escape antes del catalizador"),
            listOf("Revisa el escape en busca de fugas", "Comprueba el estado del catalizador"),
        )
        m["P0470"] = d(
            "Sensor de presión de los gases de escape: avería en el circuito", "Sensor de presión de los gases de escape", Severity.MODERADA,
            "La regeneración del filtro de partículas se gestiona con un valor estimado.",
            listOf(WIRING, "Sensor averiado", "Tubo del sensor obstruido"),
            listOf(CHECK_CONNECTOR, "Revisa el tubo del sensor al escape"),
        )
        m["P0471"] = d(
            "Sensor de presión de los gases de escape: señal fuera de rango", "Sensor de presión de los gases de escape", Severity.MODERADA,
            "La regeneración del filtro de partículas se gestiona con un valor estimado.",
            listOf("Tubo del sensor obstruido o rajado", "Sensor averiado"),
            listOf("Revisa el tubo del sensor al escape", CHECK_CONNECTOR),
        )
        m["P0544"] = d(
            "Sensor de temperatura de los gases de escape 1: avería en el circuito", "Sensor de temperatura de los gases de escape 1", Severity.MODERADA,
            "La regeneración del filtro de partículas queda limitada.",
            listOf(WIRING, "Sensor averiado"),
            listOf(CHECK_CONNECTOR, "Mide la resistencia del sensor de temperatura de escape en frío"),
        )
        m["P0545"] = d(
            "Sensor de temperatura de los gases de escape 1: señal baja", "Sensor de temperatura de los gases de escape 1", Severity.MODERADA,
            "La regeneración del filtro de partículas queda limitada.",
            listOf("Cortocircuito a masa en la señal", "Sensor averiado"),
            listOf(CHECK_CONNECTOR),
        )
        m["P0546"] = d(
            "Sensor de temperatura de los gases de escape 1: señal alta", "Sensor de temperatura de los gases de escape 1", Severity.MODERADA,
            "La regeneración del filtro de partículas queda limitada.",
            listOf("Sensor en circuito abierto o desenchufado", WIRING),
            listOf(CHECK_CONNECTOR, "Mide la continuidad del sensor de temperatura de escape"),
        )
        m["P2002"] = d(
            "Filtro de partículas: eficiencia por debajo del umbral", "Filtro de partículas (FAP/DPF)", Severity.MODERADA,
            "La centralita detecta que el filtro no retiene bien el hollín.",
            listOf("Filtro de partículas roto o vaciado", "Sensor de presión diferencial o sus tubos con fallo"),
            listOf("Revisa los dos tubos del sensor de presión diferencial (sin fugas ni obstrucciones)", "En Datos en vivo, comprueba la presión diferencial con el motor acelerado"),
        )
        m["P242F"] = d(
            "Filtro de partículas: obstrucción por acumulación de ceniza", "Filtro de partículas (FAP/DPF)", Severity.GRAVE,
            "El filtro está saturado de ceniza: más contrapresión, pérdida de potencia y regeneraciones frecuentes.",
            listOf("Filtro al final de su vida útil", "Consumo de aceite que deja ceniza en el filtro"),
            listOf("Limpia o sustituye el filtro de partículas", "Tras cambiarlo, hay que adaptar el valor de ceniza en la centralita"),
        )
        m["P2452"] = d(
            "Sensor de presión diferencial del filtro de partículas: avería en el circuito", "Sensor de presión diferencial", Severity.MODERADA,
            "La carga del filtro se estima sin lectura real; las regeneraciones pueden no hacerse a tiempo.",
            listOf(WIRING, "Sensor averiado"),
            listOf(CHECK_CONNECTOR),
        )
        m["P2453"] = d(
            "Sensor de presión diferencial del filtro de partículas: señal fuera de rango", "Sensor de presión diferencial", Severity.MODERADA,
            "La carga del filtro se calcula mal: regeneraciones a destiempo.",
            listOf("Tubos del sensor de presión diferencial cambiados de lugar, rajados u obstruidos", "Sensor averiado", "Filtro de partículas muy cargado"),
            listOf("Revisa los dos tubos del sensor de presión diferencial y su posición", "Con el motor parado la presión diferencial debe ser casi cero"),
        )
        m["P2454"] = d(
            "Sensor de presión diferencial del filtro de partículas: señal baja", "Sensor de presión diferencial", Severity.MODERADA,
            "La carga del filtro se estima sin lectura real.",
            listOf("Tubo del sensor de presión diferencial suelto o rajado", "Cortocircuito a masa en la señal", "Sensor averiado"),
            listOf("Revisa los tubos del sensor de presión diferencial", CHECK_CONNECTOR),
        )
        m["P2455"] = d(
            "Sensor de presión diferencial del filtro de partículas: señal alta", "Sensor de presión diferencial", Severity.MODERADA,
            "La carga del filtro se estima sin lectura real.",
            listOf("Tubo del sensor de presión diferencial obstruido", "Filtro de partículas muy cargado", "Sensor averiado"),
            listOf("Revisa los tubos del sensor de presión diferencial", "Comprueba el nivel de carga del filtro"),
        )
        m["P2463"] = d(
            "Filtro de partículas: acumulación excesiva de hollín", "Filtro de partículas (FAP/DPF)", Severity.GRAVE,
            "Potencia limitada para proteger el filtro. Si se sigue cargando puede ser necesaria una regeneración en taller.",
            listOf("Muchos trayectos cortos sin que se complete la regeneración", "Combustión con mucho humo (inyectores, EGR, admisión)", "Sensor que lee de más"),
            listOf(
                "Haz un trayecto de 20 minutos por autovía a más de 2.000 rpm para que regenere",
                "Si no se borra, haz una regeneración forzada con equipo de diagnosis",
            ),
        )

        // ── Velocidad, frenos y pedal
        m["P0500"] = d(
            "Sensor de velocidad del vehículo: avería", "Señal de velocidad (desde el ABS por el bus CAN)", Severity.MODERADA,
            "El limitador y el programador de velocidad dejan de funcionar; puede afectar al cuadro.",
            listOf("Avería en un sensor de rueda del ABS", "Fallo de comunicación con el ABS"),
            listOf("Lee también las averías de la centralita del ABS", "Comprueba que el velocímetro funciona"),
        )
        m["P0571"] = d(
            "Interruptor de freno: avería en el circuito", "Interruptor de luz de freno (F) / pedal de freno", Severity.MODERADA,
            "El programador de velocidad deja de funcionar y puede limitar la respuesta del acelerador.",
            listOf("Interruptor de freno desajustado o averiado", WIRING),
            listOf("Comprueba que las luces de freno se encienden al pisar el pedal", "Revisa el interruptor del pedal y su ajuste"),
        )
        m["P0504"] = d(
            "Interruptores de freno A y B: señales no coherentes", "Interruptor de luz de freno (F) / pedal de freno", Severity.MODERADA,
            "El programador de velocidad deja de funcionar.",
            listOf("Interruptor de freno desajustado o averiado"),
            listOf("Revisa el interruptor del pedal de freno y su ajuste"),
        )
        listOf("P2122" to "baja", "P2123" to "alta").forEach { (c, s) ->
            m[c] = d(
                "Sensor 1 del pedal del acelerador: señal $s", "Sensor de posición del pedal del acelerador", Severity.GRAVE,
                "El motor queda a ralentí acelerado o con respuesta muy limitada (modo de emergencia).",
                listOf(WIRING, "Sensor del pedal averiado"),
                listOf(CHECK_CONNECTOR, "En Datos en vivo → Pedal, comprueba que va de 0 a 100 % sin saltos"),
            )
        }
        listOf("P2127" to "baja", "P2128" to "alta").forEach { (c, s) ->
            m[c] = d(
                "Sensor 2 del pedal del acelerador: señal $s", "Sensor de posición del pedal del acelerador", Severity.GRAVE,
                "Respuesta del acelerador limitada (modo de emergencia).",
                listOf(WIRING, "Sensor del pedal averiado"),
                listOf(CHECK_CONNECTOR, "En Datos en vivo → Pedal (sensor 2), comprueba que sigue al sensor 1"),
            )
        }
        m["P2138"] = d(
            "Sensores 1 y 2 del pedal del acelerador: señales no coherentes", "Sensores del pedal del acelerador", Severity.GRAVE,
            "Respuesta del acelerador limitada (modo de emergencia).",
            listOf("Pedal del acelerador averiado", WIRING),
            listOf("En Datos en vivo compara Pedal y Pedal (2): deben moverse a la vez", CHECK_CONNECTOR),
        )

        // ── Chapaletas del colector
        m["P2008"] = d(
            "Chapaletas del colector de admisión: avería en el circuito de mando", "Motor de las chapaletas del colector", Severity.LEVE,
            "Más emisiones y algo menos de suavidad a bajas vueltas.",
            listOf(WIRING, "Motor averiado"),
            listOf(CHECK_CONNECTOR),
        )
        m["P2015"] = d(
            "Sensor de posición de las chapaletas del colector: señal fuera de rango", "Potenciómetro de las chapaletas del colector", Severity.LEVE,
            "Más emisiones; normalmente sin efecto en la conducción.",
            listOf("Chapaletas agarrotadas por carbonilla", "Varillaje suelto o roto", "Sensor averiado"),
            listOf("Comprueba que el varillaje de las chapaletas se mueve libre", CHECK_CONNECTOR),
        )

        // ── Alimentación y centralita
        m["P0560"] = d(
            "Tensión del sistema: avería", "Alimentación de la centralita de motor", Severity.MODERADA,
            "Funcionamiento irregular de la centralita y de los actuadores.",
            listOf("Batería en mal estado", "Masa del motor o de la centralita deficiente", "Alternador con fallo"),
            listOf("En Datos en vivo → Batería: con el motor en marcha debe estar entre 13,5 y 14,7 V", "Revisa los bornes y la masa del motor"),
        )
        m["P0562"] = d(
            "Tensión del sistema baja", "Alimentación de la centralita de motor", Severity.MODERADA,
            "Arranque difícil y posibles averías en otras centralitas.",
            listOf("Batería descargada o envejecida", "Alternador que no carga", "Bornes flojos u oxidados"),
            listOf("En Datos en vivo → Batería: con el motor en marcha debe estar entre 13,5 y 14,7 V", "Haz una prueba de carga de la batería"),
        )
        m["P0563"] = d(
            "Tensión del sistema alta", "Alimentación de la centralita de motor", Severity.GRAVE,
            "Puede dañar la batería y las centralitas.",
            listOf("Regulador del alternador averiado", "Arranque con un cargador o batería auxiliar de tensión excesiva"),
            listOf("En Datos en vivo → Batería: con el motor en marcha no debe pasar de 14,8 V"),
        )
        m["P0601"] = d(
            "Centralita de motor: error en la memoria interna", "Unidad de control del motor", Severity.GRAVE,
            "Funcionamiento impredecible del motor.",
            listOf("Programación corrupta (reprogramación interrumpida o mal hecha)", "Centralita averiada"),
            listOf("Vuelve a grabar el programa de la centralita", "Si persiste, la centralita debe repararse o sustituirse"),
        )
        m["P0606"] = d(
            "Centralita de motor: fallo del procesador", "Unidad de control del motor", Severity.GRAVE,
            "Funcionamiento impredecible del motor o modo de emergencia.",
            listOf("Centralita averiada", "Programación corrupta", "Alimentación o masa de la centralita deficiente"),
            listOf("Revisa alimentación y masas de la centralita de motor", "Vuelve a grabar el programa de la centralita"),
        )
        m["P0641"] = d(
            "Tensión de referencia A de los sensores: avería en el circuito", "Alimentación de 5 V de los sensores", Severity.GRAVE,
            "Varios sensores dejan de leer a la vez: modo de emergencia.",
            listOf("Cortocircuito en la alimentación de algún sensor", "Sensor averiado que tira de la alimentación"),
            listOf("Desconecta los sensores de uno en uno hasta que desaparezca el fallo", "Revisa el mazo en busca de roces"),
        )
        m["P0651"] = d(
            "Tensión de referencia B de los sensores: avería en el circuito", "Alimentación de 5 V de los sensores", Severity.GRAVE,
            "Varios sensores dejan de leer a la vez: modo de emergencia.",
            listOf("Cortocircuito en la alimentación de algún sensor", "Sensor averiado que tira de la alimentación"),
            listOf("Desconecta los sensores de uno en uno hasta que desaparezca el fallo", "Revisa el mazo en busca de roces"),
        )
        m["P0627"] = d(
            "Bomba de combustible (preelevadora): avería en el circuito", "Bomba de combustible del depósito", Severity.GRAVE,
            "Falta de presión de alimentación: tirones, pérdida de potencia o no arranque.",
            listOf("Relé o fusible de la bomba", WIRING, "Bomba averiada"),
            listOf("Comprueba que la bomba funciona al abrir la puerta del conductor o poner el contacto", "Revisa el fusible y el relé de la bomba"),
        )
        m["P0700"] = d(
            "Cambio: avería registrada en la centralita del cambio", "Unidad de control del cambio", Severity.MODERADA,
            "La centralita del cambio tiene su propia avería guardada.",
            listOf("Avería en el cambio automático o en su centralita"),
            listOf("Lee las averías de la centralita del cambio con un equipo de diagnosis"),
        )

        // ── Red de comunicación
        m["U0001"] = d(
            "Bus CAN de alta velocidad: avería de comunicación", "Bus CAN de tracción", Severity.GRAVE,
            "Las centralitas dejan de comunicarse entre sí: varios testigos encendidos y funciones limitadas.",
            listOf("Cableado del bus CAN dañado o con humedad", "Centralita que bloquea el bus", "Batería baja durante el arranque"),
            listOf("Comprueba la tensión de la batería", "Revisa las averías del resto de centralitas", "Mide la resistencia del bus CAN entre CAN-H y CAN-L (unos 60 Ω)"),
        )
        m["U0100"] = d(
            "Sin comunicación con la centralita de motor", "Unidad de control del motor", Severity.GRAVE,
            "Otras centralitas no reciben datos del motor.",
            listOf("Alimentación o masa de la centralita de motor", "Cableado del bus CAN", "Batería baja"),
            listOf("Comprueba la tensión de la batería", "Revisa el conector de la centralita de motor"),
        )
        m["U0101"] = d(
            "Sin comunicación con la centralita del cambio", "Unidad de control del cambio", Severity.MODERADA,
            "Otras centralitas no reciben datos del cambio.",
            listOf("Cableado del bus CAN", "Centralita del cambio sin alimentación"),
            listOf("Revisa las averías de la centralita del cambio"),
        )
        m["U0121"] = d(
            "Sin comunicación con la centralita del ABS", "Unidad de control del ABS", Severity.GRAVE,
            "Falta la señal de velocidad y el control de estabilidad puede no funcionar.",
            listOf("Cableado del bus CAN", "Fusible o alimentación de la centralita del ABS", "Centralita del ABS averiada"),
            listOf("Revisa las averías de la centralita del ABS", "Comprueba los fusibles del ABS"),
        )
        m["U0140"] = d(
            "Sin comunicación con la centralita de confort (BCM)", "Unidad de control de la red de a bordo", Severity.MODERADA,
            "Funciones de carrocería y luces pueden fallar.",
            listOf("Cableado del bus CAN", "Alimentación de la BSI"),
            listOf("Revisa las averías de la centralita de a bordo"),
        )
        m["U0155"] = d(
            "Sin comunicación con el cuadro de instrumentos", "Cuadro de instrumentos", Severity.MODERADA,
            "Indicaciones del cuadro y testigos pueden no funcionar.",
            listOf("Cableado del bus CAN", "Alimentación del cuadro", "Cuadro de instrumentos averiado"),
            listOf("Revisa las averías del cuadro de instrumentos"),
        )
        m
    }

    /** Ficha completa del código, o null si no está en el catálogo. */
    fun def(code: String): DtcDef? = defs[code.uppercase()]

    /** Título del código: el de la ficha o, si no la hay, el sistema según la norma SAE. */
    fun describe(code: String): String = def(code)?.title ?: "${system(code)}: avería"

    /** ¿Es un código propio del fabricante (no genérico SAE)? */
    fun isManufacturer(code: String): Boolean {
        val c = code.uppercase()
        val d = c.getOrNull(1) ?: return false
        return when (c.firstOrNull()) {
            'P' -> d == '1' || d == '3'
            else -> d == '1' || d == '2'
        }
    }

    /** Sistema afectado según la estructura del código (SAE J2012). */
    fun system(code: String): String {
        val c = code.uppercase()
        val third = c.getOrNull(2) ?: '0'
        return when (c.firstOrNull()) {
            'P' -> when (third) {
                '0', '1' -> "Medición de aire y combustible"
                '2' -> "Inyección de combustible"
                '3' -> "Encendido / combustión"
                '4' -> "Control de emisiones (EGR, escape, filtro de partículas)"
                '5' -> "Velocidad, ralentí y entradas auxiliares"
                '6' -> "Centralita y salidas"
                '7', '8', '9' -> "Transmisión"
                'A', 'B', 'C' -> "Propulsión híbrida"
                else -> "Motor y transmisión"
            }
            'C' -> "Chasis (frenos, suspensión, dirección)"
            'B' -> "Carrocería (airbag, confort, climatización)"
            'U' -> "Red de comunicación entre centralitas"
            else -> "Sistema desconocido"
        }
    }

    /** Tipo de fallo (byte FTB de SAE J2012) que manda la centralita junto al código. */
    fun failureType(ftb: Int): String? = when (ftb) {
        0x00 -> null
        0x01 -> "Fallo eléctrico general"
        0x02 -> "Fallo general de la señal"
        0x04 -> "Fallo interno del sistema"
        0x05 -> "Fallo de programación del sistema"
        0x06 -> "Fallo de cálculo"
        0x07 -> "Fallo mecánico"
        0x08 -> "Fallo en el mensaje del bus o en la señal"
        0x09 -> "Fallo del componente"
        0x11 -> "Cortocircuito a masa"
        0x12 -> "Cortocircuito a positivo"
        0x13 -> "Circuito abierto"
        0x14 -> "Cortocircuito a masa o circuito abierto"
        0x15 -> "Cortocircuito a positivo o circuito abierto"
        0x16 -> "Tensión del circuito por debajo del umbral"
        0x17 -> "Tensión del circuito por encima del umbral"
        0x18 -> "Corriente del circuito por debajo del umbral"
        0x19 -> "Corriente del circuito por encima del umbral"
        0x1A -> "Resistencia del circuito por debajo del umbral"
        0x1B -> "Resistencia del circuito por encima del umbral"
        0x1C -> "Tensión del circuito fuera de rango"
        0x1D -> "Corriente del circuito fuera de rango"
        0x1E -> "Resistencia del circuito fuera de rango"
        0x1F -> "Circuito intermitente"
        0x21 -> "Amplitud de la señal por debajo del mínimo"
        0x22 -> "Amplitud de la señal por encima del máximo"
        0x23 -> "Señal bloqueada en valor bajo"
        0x24 -> "Señal bloqueada en valor alto"
        0x25 -> "Forma de onda de la señal incorrecta"
        0x26 -> "Variación de la señal demasiado lenta"
        0x27 -> "Variación de la señal demasiado rápida"
        0x28 -> "Desviación (offset) de la señal"
        0x29 -> "Señal no válida"
        0x2F -> "Señal errática"
        0x31 -> "Sin señal"
        0x36 -> "Frecuencia de la señal demasiado baja"
        0x37 -> "Frecuencia de la señal demasiado alta"
        0x38 -> "Frecuencia de la señal incorrecta"
        0x41 -> "Error de suma de comprobación de la memoria"
        0x42 -> "Fallo de la memoria RAM"
        0x44 -> "Fallo de la memoria de datos"
        0x45 -> "Fallo de la memoria de programa"
        0x46 -> "Fallo de los datos de calibración o parámetros"
        0x47 -> "Fallo del vigilante (watchdog)"
        0x49 -> "Fallo electrónico interno"
        0x4B -> "Temperatura excesiva"
        0x51 -> "Centralita no programada"
        0x54 -> "Falta la calibración"
        0x55 -> "No configurado"
        0x62 -> "Las señales comparadas no coinciden"
        0x63 -> "Tiempo de respuesta del circuito o componente excedido"
        0x64 -> "Señal no plausible"
        0x67 -> "Señal incorrecta tras un evento"
        0x71 -> "Actuador bloqueado"
        0x72 -> "Actuador atascado abierto"
        0x73 -> "Actuador atascado cerrado"
        0x77 -> "No alcanza la posición pedida"
        0x78 -> "Ajuste o alineación incorrectos"
        0x7B -> "Nivel de líquido bajo"
        0x81 -> "Mensaje recibido no válido"
        0x82 -> "Contador de mensajes incorrecto"
        0x83 -> "Valor de protección del mensaje incorrecto"
        0x84 -> "Señal por debajo del rango permitido"
        0x85 -> "Señal por encima del rango permitido"
        0x86 -> "Señal no válida"
        0x87 -> "Falta el mensaje"
        0x88 -> "Bus desconectado (bus off)"
        0x8F -> "Señal errática"
        0x92 -> "Rendimiento o tiempo de respuesta incorrecto"
        0x93 -> "Sin funcionamiento"
        0x94 -> "Funcionamiento inesperado"
        0x95 -> "Montaje incorrecto"
        0x96 -> "Avería interna del componente"
        0x97 -> "Funcionamiento obstruido o bloqueado"
        0x98 -> "Temperatura excesiva del componente o del sistema"
        else -> "Tipo de fallo %02X".format(ftb)
    }
}

// ═══════════════════════════════════════════════════════════════════ Centralita de motor por apartados
// Como en los equipos de taller: la centralita, sus apartados y los componentes de cada uno, con los
// códigos de avería que corresponden a cada componente. Así se ve qué está bien y qué está mal.

class Component(val name: String, val codes: Set<String>)
class Subsystem(val name: String, val components: List<Component>)

object EngineMap {
    private fun r(from: Int, to: Int) = (from..to).map { "P%04X".format(it) }
    private fun c(name: String, vararg codes: String) = Component(name, codes.toSet())
    private fun c(name: String, codes: List<String>) = Component(name, codes.toSet())

    val subsystems: List<Subsystem> = listOf(
        Subsystem("Admisión y turbo", listOf(
            c("Medidor de masa de aire", r(0x100, 0x103)),
            c("Sensor de presión de sobrealimentación", r(0x105, 0x108)),
            c("Sensor de temperatura del aire de admisión", r(0x110, 0x113)),
            c("Regulación del turbo", "P0045", "P0234", "P0299", "P2263"),
            c("Posición de la geometría variable del turbo", "P2562", "P2563"),
            c("Chapaletas del colector de admisión", "P2008", "P2015"),
        )),
        Subsystem("Combustible e inyección", listOf(
            c("Sensor de presión del rail", r(0x190, 0x193)),
            c("Regulación de la presión de combustible", "P0087", "P0088", "P0089", "P0093"),
            c("Inyector cilindro 1", "P0201", "P0261", "P0262", "P0301"),
            c("Inyector cilindro 2", "P0202", "P0264", "P0265", "P0302"),
            c("Inyector cilindro 3", "P0203", "P0267", "P0268", "P0303"),
            c("Inyector cilindro 4", "P0204", "P0270", "P0271", "P0304"),
            c("Circuito de inyectores y combustión", "P0200", "P0300"),
            c("Sensor de temperatura del combustible", r(0x180, 0x183)),
            c("Bomba de combustible del depósito", "P0627"),
        )),
        Subsystem("Régimen y distribución", listOf(
            c("Sensor de régimen del motor", "P0335", "P0336"),
            c("Sensor del árbol de levas", "P0340", "P0341"),
            c("Sincronización cigüeñal / árbol de levas", "P0016"),
        )),
        Subsystem("Precalentamiento", listOf(
            c("Unidad de precalentamiento", "P0380", "P0670", "P0683"),
            c("Bujía de incandescencia cilindro 1", "P0671"),
            c("Bujía de incandescencia cilindro 2", "P0672"),
            c("Bujía de incandescencia cilindro 3", "P0673"),
            c("Bujía de incandescencia cilindro 4", "P0674"),
            c("Testigo de precalentamiento", "P0381"),
        )),
        Subsystem("Refrigeración", listOf(
            c("Sensor de temperatura del refrigerante", r(0x115, 0x118)),
            c("Termostato", "P0128"),
        )),
        Subsystem("Recirculación de gases (EGR)", listOf(
            c("Válvula EGR", "P0400", "P0401", "P0402", "P0403", "P0404"),
            c("Sensor de posición de la EGR", "P0405", "P0406", "P0409"),
            c("Radiador de la EGR", "P2425"),
        )),
        Subsystem("Escape y filtro de partículas", listOf(
            c("Filtro de partículas", "P2002", "P242F", "P2463"),
            c("Sensor de presión diferencial", r(0x2452, 0x2455)),
            c("Sensor de temperatura de gases de escape", "P0544", "P0545", "P0546"),
            c("Sensor de presión de gases de escape", "P0470", "P0471"),
            c("Catalizador", "P0420"),
        )),
        Subsystem("Pedales y velocidad", listOf(
            c("Pedal del acelerador", "P2122", "P2123", "P2127", "P2128", "P2138"),
            c("Interruptor de freno", "P0571", "P0504"),
            c("Señal de velocidad del vehículo", "P0500"),
        )),
        Subsystem("Alimentación y centralita", listOf(
            c("Tensión de alimentación", "P0560", "P0562", "P0563"),
            c("Centralita de motor", "P0601", "P0606"),
            c("Alimentación de 5 V de los sensores", "P0641", "P0651"),
        )),
        Subsystem("Comunicación con otras centralitas", listOf(
            c("Bus CAN de tracción", "U0001"),
            c("Centralitas conectadas (cambio, ABS, cuadro, confort)", "U0100", "U0101", "U0121", "U0140", "U0155", "P0700"),
        )),
    )

    private val index: Map<String, Pair<Subsystem, Component>> by lazy {
        val m = HashMap<String, Pair<Subsystem, Component>>()
        for (s in subsystems) for (c in s.components) for (code in c.codes) m[code] = s to c
        m
    }

    /** Apartado y componente de un código, o null si no está en el mapa (sale en "Otros códigos"). */
    fun find(code: String): Pair<Subsystem, Component>? = index[code.uppercase()]
}
