# OBD C4 Picasso

App Android para tablet o pantalla de coche que lee la OBD del **Citroën C4 Picasso I (UD) 1.6 HDi 112 CV (2010–2013)** con un adaptador **ELM327 Bluetooth** (probado con el "OBD Advanced"). También vale un cable OBD USB si la pantalla no tiene Bluetooth.

Parte de la app del Ibiza (misma interfaz, panel, radares, límites, viaje, averías), adaptada al Citroën.

## Primeros pasos
1. Enchufa el adaptador en la toma OBD (debajo del volante) y pon el contacto.
2. En el Bluetooth de la tablet, empareja el adaptador (suele salir como **OBDII** u **OBD**; PIN **1234** o **0000**).
3. Abre la app y acepta el permiso de **Dispositivos cercanos** (Bluetooth).
4. Ajustes → **Conexión**: toca tu adaptador. Desde entonces se conecta sola.
5. La primera vez que conecta, hace sola el **Escáner Citroën** (2–4 minutos). En Ajustes → Escáner Citroën → **COMPARTIR** se manda el informe.

## Qué cambia respecto a la app del Ibiza
- **Conexión Bluetooth** (perfil serie, con tres formas de abrir el canal para los clones chinos) y reconexión automática. Si hay un cable USB enchufado, se usa el cable.
- **Protocolo**: CAN 11 bit 500 kbps; si la primera vez no contesta, el adaptador busca el protocolo solo y se guarda.
- **Temperatura del aceite**: sin identificador fijo de SEAT. Se usa la estándar (015C) si el coche la da; si no, Ajustes → Temperatura del aceite → **BUSCAR** y **USAR** el candidato bueno.
- **Presión del turbo**: sin identificador fijo; dato OBD estándar o el que se confirme con **BUSCAR**.
- **Escáner Citroën** (solo lectura): valores de todos los datos OBD estándar, qué centralitas PSA contestan (motor 7E0 y 6A8, BSI 752…) y qué identificadores 22 da el motor. Sirve para añadir los sensores propios de Citroën.
- **Fichas de averías** sin referencias de piezas VAG; los títulos SAE valen para cualquier coche.
- Par motor de referencia del 1.6 HDi (270 Nm) para el consumo calculado.

## Conseguir el APK
Cada vez que se sube un cambio a GitHub, **Actions** compila la app y la publica en **Releases** como `OBD-C4Picasso.apk`. Se instala aparte de la del Ibiza (no la sustituye) y las versiones nuevas se instalan encima.

## Adaptador
- El "OBD Advanced" es un clon de ELM327 v1.5: sirve, pero es lento y algunos comandos avanzados pueden fallar.
- Si se queda corto: **OBDLink MX+** o **Vgate iCar Pro** (Bluetooth), o **OBDLink EX** (USB).
